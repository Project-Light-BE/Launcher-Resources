# Project Light 💡
**Project Light** is a texture pack for Minecraft: Bedrock Edition. 
<br>It improves the gameplay by adding features such as, ArmorHUD, Coordinates, StatusHUD, and More!

This is the official GitHub repository for the texture pack, here we keep track of additions and modifications!
If you plan to contribute then try to add short and detailed descriptions to your commits.
